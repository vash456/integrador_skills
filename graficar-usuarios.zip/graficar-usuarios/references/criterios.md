Criterios de aceptación
El script `src/reporte_registros.py` existe y corre sin errores.

Lee `data/limpio/registros_limpio.csv`.

Grafica 1 — Barras: participaciones por estado: `conteo.plot(kind="bar")`, guardada en `reportes/registros_grafica_1.png`.

Grafica 2 — Linea: participaciones por mes: `por_mes.plot(kind="line", marker="o")`, guardada en `reportes/registros_grafica_2.png`.

Grafica 3 — Barras horizontales: los 10 retos con mas participantes: `top_retos.plot(kind="barh")`, guardada en `reportes/registros_grafica_3.png`.

Cada grafica tiene `plt.title(...)`, `plt.xlabel(...)`, `plt.ylabel(...)` y `plt.tight_layout()` antes de `plt.savefig(...)`.

Se usa `plt.savefig(ruta, dpi=120)` y luego `plt.close()` (no `plt.show()`, para que el script no se quede esperando).

La carpeta se crea sola: `os.makedirs("reportes", exist_ok=True)`.

El script imprime al final las conclusiones, respondiendo por lo menos: Cual es el reto mas popular y cuantos participantes tiene; En que mes hubo mas inscripciones; Cuantas inscripciones duplicadas se encontraron y por que el back debe bloquearlas con 409.

Las tres imagenes quedan subidas al repositorio dentro de `reportes/`.
