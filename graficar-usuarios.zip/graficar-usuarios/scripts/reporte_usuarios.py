"""Reporte gráfico de la HU G01 sobre la tabla usuarios del proyecto integrador.

Uso:
    python scripts/reporte_usuarios.py usuarios_limpio.csv

Lee el CSV LIMPIO, crea tres gráficas con matplotlib, las guarda en la carpeta
reportes/ (dpi=120) e imprime la ruta de cada una y las conclusiones.
"""
import os
import sys

import matplotlib

matplotlib.use("Agg")  # Sin ventanas: el script no se queda esperando
import matplotlib.pyplot as plt
import pandas as pd

# Carpeta donde se guardan las imágenes
CARPETA_REPORTES = "reportes"
# Columnas que necesitan las gráficas y las conclusiones
COLUMNAS_NECESARIAS = ["id", "estado", "id_usuario", "id_reto", "mes"]


def cargar_datos(ruta):
    """Lee el CSV limpio y comprueba que tenga las columnas necesarias.

    Si falta la columna "mes" pero existe "fecha_registro", la calcula (AAAA-MM).
    """
    df = pd.read_csv(ruta)
    if "mes" not in df.columns and "fecha_registro" in df.columns:
        fechas = pd.to_datetime(df["fecha_registro"], errors="coerce")
        df["mes"] = fechas.dt.to_period("M").astype(str)
    faltan = [c for c in COLUMNAS_NECESARIAS if c not in df.columns]
    if faltan:
        sys.exit(f"Error: faltan las columnas {faltan} en {ruta}")
    return df


def guardar_figura(nombre):
    """Aplica tight_layout, guarda la figura actual con dpi=120, la cierra y devuelve la ruta."""
    plt.tight_layout()
    ruta = os.path.join(CARPETA_REPORTES, nombre)
    plt.savefig(ruta, dpi=120)
    plt.close()
    return ruta


def grafica_1(df):
    """Gráfica 1 (barras): participaciones por estado."""
    conteo = df["estado"].value_counts()
    fig, ax = plt.subplots(figsize=(8, 5))
    conteo.plot(kind="bar", ax=ax, color="#4C78A8")
    plt.title("Participaciones por estado")
    plt.xlabel("Estado")
    plt.ylabel("Cantidad de participaciones")
    plt.xticks(rotation=0)
    return guardar_figura("usuarios_grafica_1.png")


def grafica_2(df):
    """Gráfica 2 (línea): participaciones por mes."""
    por_mes = df.groupby("mes")["id"].count().sort_index()
    fig, ax = plt.subplots(figsize=(8, 5))
    por_mes.plot(kind="line", marker="o", ax=ax, color="#F58518")
    plt.title("Participaciones por mes")
    plt.xlabel("Mes")
    plt.ylabel("Cantidad de participaciones")
    ax.set_xticks(range(len(por_mes)))  # Muestra todos los meses en el eje
    ax.set_xticklabels(por_mes.index, rotation=45)
    plt.grid(alpha=0.3)
    return guardar_figura("usuarios_grafica_2.png")


def grafica_3(df):
    """Gráfica 3 (barras horizontales): los 10 retos con más participantes."""
    top_retos = df.groupby("id_reto")["id"].count().nlargest(10)
    fig, ax = plt.subplots(figsize=(8, 5))
    top_retos.plot(kind="barh", ax=ax, color="#54A24B")
    ax.invert_yaxis()  # El reto con más participantes queda arriba
    plt.title("Top 10 retos con más participantes")
    plt.xlabel("Cantidad de participantes")
    plt.ylabel("Reto (id_reto)")
    return guardar_figura("usuarios_grafica_3.png")


def conclusiones(df):
    """Calcula e imprime las conclusiones: reto más popular, mes pico y duplicados."""
    por_reto = df.groupby("id_reto")["id"].count()
    reto_top = por_reto.idxmax()
    por_mes = df.groupby("mes")["id"].count()
    mes_top = por_mes.idxmax()
    # Inscripciones sobrantes: mismo usuario en el mismo reto más de una vez
    duplicadas = int(df.duplicated(subset=["id_usuario", "id_reto"], keep="first").sum())

    print("\n=== Conclusiones ===")
    print(f"1. El reto más popular es el {reto_top}, con {por_reto.max()} participantes.")
    print(f"2. El mes con más inscripciones fue {mes_top}, con {por_mes.max()} participaciones.")
    if duplicadas == 0:
        print("3. No se encontraron inscripciones duplicadas (mismo usuario en el mismo reto): "
              "la limpieza ya las eliminó.")
    else:
        print(f"3. Se encontraron {duplicadas} inscripciones duplicadas "
              "(mismo usuario en el mismo reto).")
    print("   El back debe bloquearlas con 409 Conflict: la petición choca con un recurso que "
          "ya existe, así que no se crea otra fila y los conteos y rankings no se inflan. "
          "Evita también que un doble clic o un reintento registre dos veces lo mismo.")


def main():
    """Lee el archivo, crea las tres gráficas, imprime sus rutas y las conclusiones."""
    if len(sys.argv) != 2:
        sys.exit("Uso: python scripts/reporte_usuarios.py usuarios_limpio.csv")
    ruta = sys.argv[1]
    if not os.path.exists(ruta):
        sys.exit(f"Error: no existe el archivo {ruta}")

    df = cargar_datos(ruta)
    os.makedirs(CARPETA_REPORTES, exist_ok=True)
    print(f"Archivo leído: {ruta} ({len(df)} filas)")

    print("\n=== Gráficas guardadas ===")
    for grafica in (grafica_1, grafica_2, grafica_3):
        print(grafica(df))

    conclusiones(df)


if __name__ == "__main__":
    main()
