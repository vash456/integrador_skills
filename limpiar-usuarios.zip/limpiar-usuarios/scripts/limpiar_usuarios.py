#!/usr/bin/env python3
"""Limpia usuarios_sucio.csv siguiendo los criterios de la HU L01 (Kaizen).

Uso:
    python scripts/limpiar_usuarios.py usuarios_sucio.csv

Pasos: lee el CSV, imprime el diagnóstico, corrige los errores, imprime el
diagnóstico otra vez, muestra cuántas filas se eliminaron y guarda
usuarios_limpio.csv en la misma carpeta del archivo de entrada.
"""

import sys
from pathlib import Path

import pandas as pd

# Columnas que, si existen en el archivo, no pueden quedar con nulos.
COLUMNAS_OBLIGATORIAS = ["id_usuario", "id_reto", "fecha_registro", "estado"]
PAR_PARTICIPACION = ["id_usuario", "id_reto"]
NOMBRE_SALIDA = "usuarios_limpio.csv"


def leer_csv(ruta: Path) -> pd.DataFrame:
    """Lee el CSV sucio con pd.read_csv() y devuelve el DataFrame."""
    if not ruta.exists():
        sys.exit(f"ERROR: no existe el archivo '{ruta}'.")
    return pd.read_csv(ruta)


def imprimir_diagnostico(df: pd.DataFrame, titulo: str) -> None:
    """Imprime shape, info, nulos por columna y cantidad de duplicados exactos."""
    print(f"\n===== {titulo} =====")
    print(f"df.shape: {df.shape}")
    print("\ndf.info():")
    df.info()
    print("\ndf.isna().sum():")
    print(df.isna().sum())
    print(f"\ndf.duplicated().sum(): {df.duplicated().sum()}")


def quitar_duplicados_exactos(df: pd.DataFrame) -> pd.DataFrame:
    """Quita las filas idénticas con df.drop_duplicates() e informa cuántas."""
    antes = len(df)
    df = df.drop_duplicates()
    print(f"- Duplicados exactos eliminados: {antes - len(df)}")
    return df


def convertir_fecha(df: pd.DataFrame) -> pd.DataFrame:
    """Convierte fecha_registro a datetime aunque venga en dos formatos.

    Las fechas ISO (aaaa-mm-dd) se leen tal cual y el resto (dd/mm/aaaa) con
    dayfirst=True, porque dayfirst sobre una fecha ISO invierte día y mes.
    Las fechas que no se puedan interpretar quedan como NaT (errors="coerce").
    """
    if "fecha_registro" not in df.columns:
        print("- AVISO: no existe 'fecha_registro'; se omite la conversión.")
        return df
    texto = df["fecha_registro"].astype("string").str.strip()
    es_iso = texto.str.match(r"^\d{4}-\d{2}-\d{2}").fillna(False).astype(bool)
    fechas = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns]")
    fechas[es_iso] = pd.to_datetime(texto[es_iso], format="ISO8601", errors="coerce")
    fechas[~es_iso] = pd.to_datetime(
        texto[~es_iso], format="mixed", dayfirst=True, errors="coerce"
    )
    df["fecha_registro"] = fechas
    print(f"- Fechas no interpretables (NaT): {df['fecha_registro'].isna().sum()}")
    return df


def unificar_estado(df: pd.DataFrame) -> pd.DataFrame:
    """Unifica estado: sin espacios en los bordes, MAYÚSCULAS y espacios -> '_'."""
    if "estado" not in df.columns:
        print("- AVISO: no existe 'estado'; se omite la unificación.")
        return df
    df["estado"] = (
        df["estado"].astype("string").str.strip().str.upper().str.replace(" ", "_")
    )
    print(f"- Valores de estado tras unificar: {sorted(df['estado'].dropna().unique())}")
    return df


def rellenar_observaciones(df: pd.DataFrame) -> pd.DataFrame:
    """Rellena observacion vacía (nula o solo espacios) con 'Sin observacion'."""
    if "observacion" not in df.columns:
        print("- AVISO: no existe 'observacion'; se omite el relleno.")
        return df
    vacias = df["observacion"].isna() | df["observacion"].astype("string").str.strip().eq("")
    df["observacion"] = df["observacion"].mask(vacias).fillna("Sin observacion")
    print(f"- Observaciones rellenadas: {int(vacias.sum())}")
    return df


def quitar_participaciones_repetidas(df: pd.DataFrame) -> pd.DataFrame:
    """Detecta pares (id_usuario, id_reto) repetidos, imprime cuántos y deja el primero."""
    if not all(c in df.columns for c in PAR_PARTICIPACION):
        print("- AVISO: faltan 'id_usuario' o 'id_reto'; se omiten las participaciones repetidas.")
        return df
    repetidos = df[df.duplicated(subset=PAR_PARTICIPACION, keep=False)]
    print(f"- Filas con participación repetida (id_usuario, id_reto): {len(repetidos)}")
    return df.drop_duplicates(subset=PAR_PARTICIPACION, keep="first")


def crear_columna_mes(df: pd.DataFrame) -> pd.DataFrame:
    """Crea la columna mes (periodo AAAA-MM) a partir de fecha_registro."""
    if "fecha_registro" in df.columns:
        df["mes"] = df["fecha_registro"].dt.to_period("M")
    return df


def quitar_nulos_obligatorios(df: pd.DataFrame) -> pd.DataFrame:
    """Elimina filas con nulos en las columnas obligatorias que existan en el archivo."""
    obligatorias = [c for c in COLUMNAS_OBLIGATORIAS if c in df.columns]
    antes = len(df)
    df = df.dropna(subset=obligatorias)
    print(f"- Filas con nulos en {obligatorias} eliminadas: {antes - len(df)}")
    return df


def verificar_resultado(df: pd.DataFrame) -> None:
    """Comprueba que no queden nulos obligatorios ni duplicados exactos."""
    obligatorias = [c for c in COLUMNAS_OBLIGATORIAS if c in df.columns]
    nulos = int(df[obligatorias].isna().sum().sum())
    duplicados = int(df.duplicated().sum())
    print("\nVerificación final:")
    print(f"- Nulos en columnas obligatorias: {nulos} -> {'PASA' if nulos == 0 else 'FALLA'}")
    print(f"- Duplicados exactos: {duplicados} -> {'PASA' if duplicados == 0 else 'FALLA'}")


def limpiar(df: pd.DataFrame) -> pd.DataFrame:
    """Aplica todos los pasos de limpieza en el orden de la HU L01."""
    print("\n===== LIMPIEZA =====")
    df = quitar_duplicados_exactos(df)
    df = convertir_fecha(df)
    df = unificar_estado(df)
    df = rellenar_observaciones(df)
    df = quitar_participaciones_repetidas(df)
    df = crear_columna_mes(df)
    df = quitar_nulos_obligatorios(df)
    # Al unificar los valores pueden aparecer nuevos duplicados exactos.
    df = quitar_duplicados_exactos(df)
    return df


def guardar_csv(df: pd.DataFrame, ruta_entrada: Path) -> Path:
    """Guarda el resultado como usuarios_limpio.csv junto al archivo de entrada."""
    ruta_salida = ruta_entrada.parent / NOMBRE_SALIDA
    df.to_csv(ruta_salida, index=False, encoding="utf-8")
    return ruta_salida


def main() -> None:
    """Punto de entrada: lee, diagnostica, limpia, diagnostica, resume y guarda."""
    if len(sys.argv) != 2:
        sys.exit("Uso: python scripts/limpiar_usuarios.py usuarios_sucio.csv")
    ruta = Path(sys.argv[1])

    df = leer_csv(ruta)
    filas_antes = len(df)
    imprimir_diagnostico(df, "DIAGNÓSTICO ANTES")

    df = limpiar(df)

    imprimir_diagnostico(df, "DIAGNÓSTICO DESPUÉS")
    print(f"\nFilas antes: {filas_antes} | después: {len(df)} | eliminadas: {filas_antes - len(df)}")
    verificar_resultado(df)

    ruta_salida = guardar_csv(df, ruta)
    print(f"\nArchivo limpio guardado en: {ruta_salida}")


if __name__ == "__main__":
    main()
