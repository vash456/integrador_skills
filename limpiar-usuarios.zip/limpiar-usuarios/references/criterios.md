hu limpieza
Criterios de aceptación
El script `src/limpiar_registros.py` existe y corre sin errores.

Lee `data/crudo/registros_sucio.csv` con `pd.read_csv()`.

Al inicio imprime el diagnostico: `df.shape`, `df.info()`, `df.isna().sum()` y `df.duplicated().sum()`.

Quitar los duplicados exactos con `df.drop_duplicates()`.

Convertir la fecha (aunque venga en dos formatos): `df["fecha_registro"] = pd.to_datetime(df["fecha_registro"], format="mixed", dayfirst=True, errors="coerce")`.

Unificar el estado: `df["estado"] = df["estado"].str.strip().str.upper().str.replace(" ", "_")`.

Rellenar las observaciones vacias: `df["observacion"] = df["observacion"].fillna("Sin observacion")`.

Detectar las participaciones repetidas: `repetidos = df[df.duplicated(subset=["id_usuario", "id_reto"], keep=False)]` e imprimir cuantas son.

Dejar solo la primera participacion de cada par: `df = df.drop_duplicates(subset=["id_usuario", "id_reto"], keep="first")`.

Crear la columna `mes` para agrupar despues: `df["mes"] = df["fecha_registro"].dt.to_period("M")`.

Al final vuelve a imprimir `df.shape` y `df.isna().sum()`, y muestra cuantas filas se eliminaron.

Guarda el resultado en `data/limpio/registros_limpio.csv` con `df.to_csv(ruta, index=False, encoding="utf-8")`.

Despues de limpiar no queda NINGUN nulo en las columnas obligatorias ni ningun duplicado exacto.
