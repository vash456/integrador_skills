hu consultas
Criterios de aceptación
El script `src/consultas_registros.py` existe y corre sin errores.

Lee `data/limpio/registros_limpio.csv` (el archivo LIMPIO, no el sucio).

Consulta 1 — Participaciones ya finalizadas: `finalizados = df[df["estado"] == "FINALIZADO"]`.

Consulta 2 — Participaciones repetidas (mismo usuario en el mismo reto): `repetidos = df[df.duplicated(subset=["id_usuario", "id_reto"], keep=False)]`.

Consulta 3 — Cuantas participaciones hay por estado: `conteo = df["estado"].value_counts()`.

Consulta 4 — GROUPBY: los 10 retos con mas participantes: `top_retos = df.groupby("id_reto")["id"].count().nlargest(10)`.

Consulta 5 — GROUPBY por mes: cuantas participaciones hubo cada mes: `por_mes = df.groupby("mes")["id"].count()`.

Al menos 2 de las cinco consultas usan `groupby`.

Cada consulta esta en su propia funcion, con un `print()` que dice que pregunta responde.

Cada resultado se guarda como `data/limpio/registros_consulta_N.csv`.

Al ejecutar el script se ven las cinco respuestas en consola, en orden.
