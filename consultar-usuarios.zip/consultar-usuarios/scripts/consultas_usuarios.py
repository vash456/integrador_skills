"""Consultas de la HU Q01 sobre la tabla usuarios del proyecto integrador.

Uso:
    python scripts/consultas_usuarios.py usuarios_limpio.csv

Lee el CSV LIMPIO (no el sucio), resuelve las cinco consultas, imprime el
título y el resultado de cada una en orden y guarda usuarios_consulta_N.csv
en la misma carpeta del archivo de entrada.
"""
import sys
from pathlib import Path

import pandas as pd

# Columnas que necesitan las cinco consultas
COLUMNAS_NECESARIAS = ["id", "estado", "id_usuario", "id_reto", "mes"]
# Máximo de filas que se muestran en consola en las consultas largas
FILAS_EN_CONSOLA = 10


def cargar_datos(ruta):
    """Lee el CSV limpio y comprueba que tenga las columnas que piden las consultas.

    Si falta la columna "mes" pero existe "fecha_registro", la calcula (AAAA-MM).
    """
    df = pd.read_csv(ruta)
    if "mes" not in df.columns and "fecha_registro" in df.columns:
        fechas = pd.to_datetime(df["fecha_registro"], errors="coerce")
        df["mes"] = fechas.dt.to_period("M").astype(str)
    faltan = [c for c in COLUMNAS_NECESARIAS if c not in df.columns]
    if faltan:
        sys.exit(f"Error: faltan las columnas {faltan} en {ruta}")
    return df


def mostrar(titulo, resultado, limite=None):
    """Imprime el título de la consulta y su resultado (con tope opcional de filas)."""
    print(f"\n=== {titulo} ===")
    if len(resultado) == 0:
        print("(sin resultados)")
        return
    if limite is not None and len(resultado) > limite:
        print(f"Total: {len(resultado)} filas. Primeras {limite} (el resto está en el CSV):")
        print(resultado.head(limite).to_string(index=False))
    else:
        print(resultado.to_string(index=False))


def guardar(resultado, carpeta, n):
    """Guarda el resultado de la consulta N como usuarios_consulta_N.csv."""
    resultado.to_csv(carpeta / f"usuarios_consulta_{n}.csv", index=False)


def consulta_1(df):
    """Consulta 1: participaciones ya finalizadas (estado == FINALIZADO)."""
    finalizados = df[df["estado"] == "FINALIZADO"]
    mostrar("Consulta 1 - ¿Qué participaciones ya finalizaron?", finalizados, FILAS_EN_CONSOLA)
    return finalizados


def consulta_2(df):
    """Consulta 2: participaciones repetidas (mismo usuario en el mismo reto)."""
    repetidos = df[df.duplicated(subset=["id_usuario", "id_reto"], keep=False)]
    repetidos = repetidos.sort_values(["id_usuario", "id_reto"])
    mostrar("Consulta 2 - ¿Qué usuarios participan repetidos en el mismo reto?",
            repetidos, FILAS_EN_CONSOLA)
    return repetidos


def consulta_3(df):
    """Consulta 3: cuántas participaciones hay por estado (value_counts)."""
    conteo = df["estado"].value_counts().rename_axis("estado").reset_index(name="participaciones")
    mostrar("Consulta 3 - ¿Cuántas participaciones hay por estado?", conteo)
    return conteo


def consulta_4(df):
    """Consulta 4 (GROUPBY): los 10 retos con más participantes."""
    top = df.groupby("id_reto")["id"].count().nlargest(10)
    top = top.rename("participaciones").reset_index()
    mostrar("Consulta 4 - ¿Cuáles son los 10 retos con más participantes?", top)
    return top


def consulta_5(df):
    """Consulta 5 (GROUPBY): cuántas participaciones hubo cada mes."""
    por_mes = df.groupby("mes")["id"].count().sort_index()
    por_mes = por_mes.rename("participaciones").reset_index()
    mostrar("Consulta 5 - ¿Cuántas participaciones hubo cada mes?", por_mes)
    return por_mes


def main():
    """Lee el archivo recibido, ejecuta las cinco consultas en orden y guarda los CSV."""
    if len(sys.argv) != 2:
        sys.exit("Uso: python scripts/consultas_usuarios.py usuarios_limpio.csv")
    ruta = Path(sys.argv[1])
    if not ruta.exists():
        sys.exit(f"Error: no existe el archivo {ruta}")

    df = cargar_datos(ruta)
    print(f"Archivo leído: {ruta} ({len(df)} filas, {len(df.columns)} columnas)")

    consultas = [consulta_1, consulta_2, consulta_3, consulta_4, consulta_5]
    for n, consulta in enumerate(consultas, start=1):
        resultado = consulta(df)
        guardar(resultado, ruta.parent, n)

    print(f"\nListo: se guardaron usuarios_consulta_1.csv ... usuarios_consulta_5.csv en {ruta.parent}")


if __name__ == "__main__":
    main()
