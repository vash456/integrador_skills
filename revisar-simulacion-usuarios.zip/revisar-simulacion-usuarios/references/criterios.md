hu simulacion
Criterios de aceptación
El script `src/simular_registros.py` existe y corre con `python src/simular_registros.py` sin errores.

Al inicio se declaran las constantes: `ESTADOS`, `IDS_USUARIO`, `IDS_RETO`.

Se generan 800 filas con estas columnas: id (texto (UUID)), fecha_registro (fecha y hora), observacion (texto), estado (texto), id_usuario (texto (UUID)), id_reto (texto (UUID)).

`id` se genera con `str(uuid.uuid4())`.

`fecha_registro` se genera con `fake.date_time_between(start_date="-1y", end_date="now")`.

`observacion` se genera con `fake.sentence(nb_words=10)`.

`estado` se genera con `random.choice(ESTADOS)`.

`id_usuario` se genera con `random.choice(IDS_USUARIO)`.

`id_reto` se genera con `random.choice(IDS_RETO)`.

La semilla esta fija: `Faker.seed(42)` y `random.seed(42)`, para que el archivo sea reproducible.

Se ensucia `fecha_registro`: dos formatos mezclados: "2026-03-15 14:30:00" y "15/03/2026 14:30".

Se ensucia `observacion`: 20% en None (nulos).

Se ensucia `estado`: variantes: 'inscrito', 'EN PROCESO', ' Finalizado '.

10% con el par `id_usuario` + `id_reto` REPETIDO: el mismo usuario inscrito dos veces en el mismo reto (eso el back lo prohibe con 409).

5% de las filas repetidas tal cual (duplicados exactos).

Todo se arma en una funcion `generar_registros(n=800)` que **devuelve el DataFrame** (`return df`), para poder importarla desde el script de exportacion.

El bloque `if __name__ == "__main__":` solo imprime `df.shape`, `df.head()` y `df.isna().sum()` para revisar que los datos quedaron sucios.


hu exportacion

Criterios de aceptación
El script `src/exportar_registros.py` existe y corre sin errores.

Importa la funcion del script anterior (`from importlib import import_module` o renombrando el modulo) y NO vuelve a copiar el codigo de generacion.

Genera `data/crudo/registros_sucio.csv` con `df.to_csv(ruta, index=False, encoding="utf-8")`.

Genera `data/crudo/registros_sucio.xlsx` con `df.to_excel(ruta, index=False, sheet_name="registros")`.

Genera `data/crudo/registros_sucio.json` con `df.to_json(ruta, orient="records", force_ascii=False, indent=2)`.

La carpeta se crea sola si no existe: `os.makedirs("data/crudo", exist_ok=True)`.

Al final el script imprime la ruta y el tamaño (`df.shape`) de cada archivo generado.

`requirements.txt` incluye: pandas (version 2.x), faker, openpyxl y matplotlib.

Los tres archivos quedan versionados en Git (o, si pesan mucho, se documenta en el README como generarlos).
