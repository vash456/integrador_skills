---
name: revisar-simulacion-usuarios
description: Revisa la simulación (HU F01) y la exportación (HU X01) de la tabla usuarios del proyecto integrador contra los criterios de Kaizen, encuentra lo que está mal y entrega el código corregido. Úsala cuando alguien suba su script simular_usuarios.py o exportar_usuarios.py, suba los archivos usuarios_sucio.csv, .xlsx o .json o pida revisar o corregir su simulación o su exportación de usuarios.
---

# Revisar simulacion usuarios

Revisa la simulación (HU F01) y la exportación (HU X01) de la tabla usuarios del proyecto integrador contra los criterios de Kaizen, encuentra lo que está mal y entrega el código corregido. Trabaja en este orden y no te saltes pasos.

## Paso 1. Revisar lo que llegó

Revisa los scripts simular_usuarios.py y exportar_usuarios.py y, si existen, los archivos usuarios_sucio.csv, .xlsx y .json. Si falta algo, pídelo en una sola pregunta.

## Paso 2. Consultar la guía

Lee `references/criterios.md`: tiene los criterios de aceptación de las HU F01 y X01 de la tabla usuarios, copiados de Kaizen. No inventes reglas que no estén ahí.

## Paso 3. Procesar con el script

```bash
python scripts/revisar_datos.py usuarios_sucio.csv
```

Cuenta las filas, revisa que estén las columnas que pide la HU y cuenta los nulos y los duplicados de cada columna. Usa las rutas reales de los archivos que subió la persona. Copia lo que imprime el script sin cambiar ningún resultado. Si no llegó el archivo que necesita el script, dilo y sigue con lo demás.

## Paso 4. Responder

Responde en español, en este orden:

1. Empieza con la conclusión en una frase.
2. Muestra una tabla con cada criterio en PASA o FALLA y los dos scripts corregidos.
3. Explica cada problema con el valor encontrado y el esperado.
4. Termina con el siguiente paso que debe dar la persona.
