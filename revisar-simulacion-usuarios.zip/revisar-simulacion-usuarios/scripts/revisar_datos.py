#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
revisar_datos.py - Skill "revisar-simulacion-usuarios".

Revisa la simulacion (HU F01) y la exportacion (HU X01) del proyecto
integrador contra los criterios de references/criterios.md.

Uso:
    python scripts/revisar_datos.py usuarios_sucio.csv
    python scripts/revisar_datos.py usuarios_sucio.xlsx
    python scripts/revisar_datos.py usuarios_sucio.json

Imprime una tabla Markdown: Comprobacion | Esperado | Encontrado | Estado.
Codigo de salida: 0 si todo PASA, 1 si alguna comprobacion FALLA, 2 si hay
un error de uso o de lectura.

Dependencias: libreria estandar. pandas + openpyxl solo para leer .xlsx.
"""

import csv
import json
import os
import sys
import uuid
from datetime import datetime

# ---------------------------------------------------------------------------
# Criterios (tomados de references/criterios.md). Si la HU cambia, se edita aqui.
# ---------------------------------------------------------------------------
NOMBRE_BASE_ESPERADO = "registros_sucio"   # HU X01: data/crudo/registros_sucio.*
HOJA_EXCEL_ESPERADA = "registros"          # HU X01: sheet_name="registros"
FILAS_ESPERADAS = 800                      # HU F01: generar_registros(n=800)
COLUMNAS_ESPERADAS = [
    "id", "fecha_registro", "observacion", "estado", "id_usuario", "id_reto",
]
PCT_NULOS_OBSERVACION = 0.20               # 20% de observacion en None
TOLERANCIA_NULOS = 0.05                    # +-5 puntos porcentuales
PCT_DUPLICADOS_EXACTOS = 0.05              # 5% de filas repetidas tal cual
TOLERANCIA_DUPLICADOS = 0.03               # +-3 puntos porcentuales
PCT_PARES_REPETIDOS = 0.10                 # 10% con el par usuario+reto repetido
VARIANTES_ESTADO = ["inscrito", "EN PROCESO", " Finalizado "]
FORMATOS_FECHA = {
    "ISO": "%Y-%m-%d %H:%M:%S",            # 2026-03-15 14:30:00
    "DD/MM": "%d/%m/%Y %H:%M",             # 15/03/2026 14:30
}
COLUMNAS_UUID = ["id", "id_usuario", "id_reto"]


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def es_nulo(valor):
    """Devuelve True si el valor cuenta como nulo: None, NaN o cadena vacia."""
    if valor is None or valor == "":
        return True
    return isinstance(valor, float) and valor != valor  # NaN != NaN


def valores_columna(filas, columna):
    """Devuelve los valores de una columna como texto; los nulos quedan en None."""
    return [None if es_nulo(f.get(columna)) else str(f.get(columna)) for f in filas]


def contar_repetidos(valores):
    """Cuenta cuantos valores no nulos ya habian aparecido antes (excluye nulos)."""
    vistos, repetidos = set(), 0
    for v in valores:
        if v is None:
            continue
        if v in vistos:
            repetidos += 1
        else:
            vistos.add(v)
    return repetidos


def porcentaje(parte, total):
    """Formatea parte/total como porcentaje con un decimal (ej. '19.8%')."""
    return f"{100 * parte / total:.1f}%" if total else "0.0%"


def rango(pct, tolerancia, n):
    """Devuelve (minimo, maximo) de filas para un porcentaje +- tolerancia."""
    return max(0, round(n * (pct - tolerancia))), round(n * (pct + tolerancia))


def resultado(comprobacion, esperado, encontrado, ok):
    """Arma una fila de la tabla; el estado es PASA o FALLA segun 'ok'."""
    return (comprobacion, esperado, encontrado, "PASA" if ok else "FALLA")


def es_uuid_valido(valor):
    """True si el texto es un UUID valido en su forma canonica (con guiones)."""
    try:
        return str(uuid.UUID(valor)) == valor.lower()
    except ValueError:
        return False


def clasificar_fecha(valor):
    """Devuelve 'ISO', 'DD/MM' u 'otro' segun el formato de la fecha."""
    for nombre, formato in FORMATOS_FECHA.items():
        try:
            datetime.strptime(valor, formato)
            return nombre
        except ValueError:
            continue
    return "otro"


# ---------------------------------------------------------------------------
# Lectura de archivos: cada lector devuelve (columnas, filas, hoja)
# ---------------------------------------------------------------------------
def leer_csv(ruta):
    """Lee un CSV en UTF-8 con la libreria estandar (la hoja no aplica)."""
    with open(ruta, newline="", encoding="utf-8-sig") as f:
        lector = csv.DictReader(f)
        filas = list(lector)
        return list(lector.fieldnames or []), filas, None


def leer_json(ruta):
    """Lee un JSON orient='records' (lista de objetos) con la libreria estandar."""
    with open(ruta, encoding="utf-8") as f:
        datos = json.load(f)
    if not isinstance(datos, list) or not all(isinstance(d, dict) for d in datos):
        raise ValueError("El JSON debe ser una lista de objetos (orient='records').")
    columnas = []
    for registro in datos:
        for clave in registro:
            if clave not in columnas:
                columnas.append(clave)
    return columnas, datos, None


def leer_excel(ruta):
    """Lee la primera hoja de un .xlsx con pandas (todo como texto) y devuelve su nombre."""
    try:
        import pandas as pd
    except ImportError:
        raise SystemExit("Para leer .xlsx instala: pip install pandas openpyxl")
    libro = pd.ExcelFile(ruta)
    hoja = libro.sheet_names[0]
    df = libro.parse(hoja, dtype=str, keep_default_na=False, na_values=[""])
    filas = df.astype(object).where(df.notna(), None).to_dict("records")
    return [str(c) for c in df.columns], filas, hoja


LECTORES = {".csv": leer_csv, ".json": leer_json, ".xlsx": leer_excel}


# ---------------------------------------------------------------------------
# Comprobaciones
# ---------------------------------------------------------------------------
def revisar_archivo(ruta, hoja):
    """HU X01: nombre del archivo exportado y, en Excel, nombre de la hoja."""
    nombre = os.path.basename(ruta)
    base, ext = os.path.splitext(nombre)
    filas = [resultado("Nombre del archivo", NOMBRE_BASE_ESPERADO + ext, nombre,
                       base == NOMBRE_BASE_ESPERADO)]
    if hoja is not None:
        filas.append(resultado("Nombre de la hoja Excel", HOJA_EXCEL_ESPERADA, hoja,
                               hoja == HOJA_EXCEL_ESPERADA))
    return filas


def revisar_estructura(columnas, filas):
    """HU F01: cuenta las filas y verifica que esten las columnas pedidas."""
    faltan = [c for c in COLUMNAS_ESPERADAS if c not in columnas]
    sobran = [c for c in columnas if c not in COLUMNAS_ESPERADAS]
    detalle = []
    if faltan:
        detalle.append("faltan: " + ", ".join(faltan))
    if sobran:
        detalle.append("sobran: " + ", ".join(sobran))
    return [
        resultado("Filas", str(FILAS_ESPERADAS), str(len(filas)),
                  len(filas) == FILAS_ESPERADAS),
        resultado("Columnas de la HU", f"{len(COLUMNAS_ESPERADAS)} columnas: "
                  + ", ".join(COLUMNAS_ESPERADAS),
                  "; ".join(detalle) if detalle else f"{len(columnas)} columnas, todas presentes",
                  not detalle),
    ]


def revisar_nulos(columnas, filas):
    """Cuenta los nulos de cada columna: solo observacion debe rondar el 20%."""
    n, salida = len(filas), []
    for col in COLUMNAS_ESPERADAS:
        nombre = f"Nulos en {col}"
        if col not in columnas:
            salida.append(resultado(nombre, "columna presente", "columna ausente", False))
            continue
        nulos = sum(1 for v in valores_columna(filas, col) if v is None)
        encontrado = f"{nulos} ({porcentaje(nulos, n)})"
        if col == "observacion":
            minimo, maximo = rango(PCT_NULOS_OBSERVACION, TOLERANCIA_NULOS, n)
            salida.append(resultado(nombre, f"~20% ({minimo}-{maximo})", encontrado,
                                    minimo <= nulos <= maximo))
        else:
            salida.append(resultado(nombre, "0", encontrado, nulos == 0))
    return salida


def revisar_duplicados(columnas, filas):
    """Cuenta los duplicados de cada columna, de los pares usuario+reto y de las filas completas."""
    n, salida = len(filas), []
    min_ex, max_ex = rango(PCT_DUPLICADOS_EXACTOS, TOLERANCIA_DUPLICADOS, n)
    for col in COLUMNAS_ESPERADAS:
        nombre = f"Duplicados en {col}"
        if col not in columnas:
            salida.append(resultado(nombre, "columna presente", "columna ausente", False))
            continue
        dup = contar_repetidos(valores_columna(filas, col))
        encontrado = f"{dup} ({porcentaje(dup, n)})"
        if col == "id":
            salida.append(resultado(nombre, f"~5% ({min_ex}-{max_ex})", encontrado,
                                    min_ex <= dup <= max_ex))
        elif col in ("fecha_registro", "observacion"):
            salida.append(resultado(nombre, f"<= {max_ex} (solo copias exactas)",
                                    encontrado, dup <= max_ex))
        else:  # estado, id_usuario, id_reto salen de listas cortas con random.choice
            salida.append(resultado(nombre, "> 0 (valores de una lista corta)",
                                    encontrado, dup > 0))

    minimo_pares = round(n * PCT_PARES_REPETIDOS)
    if "id_usuario" in columnas and "id_reto" in columnas:
        pares = list(zip(valores_columna(filas, "id_usuario"),
                         valores_columna(filas, "id_reto")))
        pares = [p if None not in p else None for p in pares]
        rep = contar_repetidos(pares)
        salida.append(resultado("Pares id_usuario + id_reto repetidos",
                                f">= 10% ({minimo_pares})",
                                f"{rep} ({porcentaje(rep, n)})", rep >= minimo_pares))
    else:
        salida.append(resultado("Pares id_usuario + id_reto repetidos",
                                f">= 10% ({minimo_pares})", "columnas ausentes", False))

    completas = [tuple(None if es_nulo(f.get(c)) else str(f.get(c)) for c in columnas)
                 for f in filas]
    exactas = contar_repetidos(completas)
    salida.append(resultado("Filas duplicadas exactas", f"~5% ({min_ex}-{max_ex})",
                            f"{exactas} ({porcentaje(exactas, n)})",
                            min_ex <= exactas <= max_ex))
    return salida


def revisar_suciedad(columnas, filas):
    """HU F01: formatos de fecha mezclados, variantes de estado y UUID validos."""
    salida = []
    if "fecha_registro" in columnas:
        conteo = {"ISO": 0, "DD/MM": 0, "otro": 0}
        for v in valores_columna(filas, "fecha_registro"):
            if v is not None:
                conteo[clasificar_fecha(v)] += 1
        salida.append(resultado(
            "Formatos de fecha_registro",
            '2 mezclados: "2026-03-15 14:30:00" y "15/03/2026 14:30"',
            f"ISO {conteo['ISO']} / DD/MM {conteo['DD/MM']} / otro {conteo['otro']}",
            conteo["ISO"] > 0 and conteo["DD/MM"] > 0 and conteo["otro"] == 0))
    else:
        salida.append(resultado("Formatos de fecha_registro", "2 formatos mezclados",
                                "columna ausente", False))

    esperado = "variantes: " + ", ".join(repr(v) for v in VARIANTES_ESTADO)
    if "estado" in columnas:
        presentes = set(v for v in valores_columna(filas, "estado") if v is not None)
        faltan = [v for v in VARIANTES_ESTADO if v not in presentes]
        salida.append(resultado(
            "Variantes de estado", esperado,
            "todas presentes" if not faltan else "faltan: " + ", ".join(repr(v) for v in faltan),
            not faltan))
    else:
        salida.append(resultado("Variantes de estado", esperado, "columna ausente", False))

    for col in COLUMNAS_UUID:
        nombre = f"UUID validos en {col}"
        if col not in columnas:
            salida.append(resultado(nombre, "0 invalidos", "columna ausente", False))
            continue
        malos = [v for v in valores_columna(filas, col)
                 if v is not None and not es_uuid_valido(v)]
        ejemplo = f" (ej.: {malos[0][:20]!r})" if malos else ""
        salida.append(resultado(nombre, "0 invalidos", f"{len(malos)} invalidos{ejemplo}",
                                not malos))
    return salida


# ---------------------------------------------------------------------------
# Salida
# ---------------------------------------------------------------------------
def escapar(celda):
    """Escapa las barras verticales y los saltos de linea para la tabla Markdown."""
    return str(celda).replace("|", "\\|").replace("\n", " ")


def imprimir_tabla(resultados):
    """Imprime la tabla Markdown Comprobacion | Esperado | Encontrado | Estado."""
    print("| Comprobación | Esperado | Encontrado | Estado |")
    print("|---|---|---|---|")
    for fila in resultados:
        print("| " + " | ".join(escapar(c) for c in fila) + " |")


def main(argv):
    """Punto de entrada: lee el archivo, ejecuta las comprobaciones e imprime la tabla."""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # tildes correctas en Windows
    if len(argv) != 2:
        print("Uso: python scripts/revisar_datos.py usuarios_sucio.csv", file=sys.stderr)
        return 2
    ruta = argv[1]
    ext = os.path.splitext(ruta)[1].lower()
    if not os.path.isfile(ruta):
        print(f"No existe el archivo: {ruta}", file=sys.stderr)
        return 2
    if ext not in LECTORES:
        print(f"Extension no soportada ({ext}). Usa .csv, .xlsx o .json", file=sys.stderr)
        return 2
    try:
        columnas, filas, hoja = LECTORES[ext](ruta)
    except Exception as error:  # archivo corrupto, JSON mal formado, etc.
        print(f"No se pudo leer {ruta}: {error}", file=sys.stderr)
        return 2

    resultados = (revisar_archivo(ruta, hoja)
                  + revisar_estructura(columnas, filas)
                  + revisar_nulos(columnas, filas)
                  + revisar_duplicados(columnas, filas)
                  + revisar_suciedad(columnas, filas))
    imprimir_tabla(resultados)
    fallas = sum(1 for r in resultados if r[3] == "FALLA")
    print(f"\nResumen: {len(resultados) - fallas} PASA, {fallas} FALLA")
    return 1 if fallas else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
